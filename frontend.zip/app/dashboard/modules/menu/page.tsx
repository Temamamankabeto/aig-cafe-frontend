"use client";

import { useEffect, useState } from "react";
import { MenuManagementPage } from "@/components/menu-management";
import { authService, canonicalRoleName } from "@/services/auth/auth.service";
import type { MenuRoleScope } from "@/types/menu-management";

export default function MenuPage() {
  const [scope, setScope] = useState<MenuRoleScope | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function resolveScope() {
      try {
        await authService.hydrateSession();

        const roles = authService.getStoredRoles();
        const isFoodController = roles.some(
          (role) => canonicalRoleName(role) === "F&B Controller",
        );

        if (!cancelled) {
          setScope(isFoodController ? "food-controller" : "admin");
        }
      } catch {
        if (!cancelled) {
          setScope("admin");
        }
      }
    }

    void resolveScope();

    return () => {
      cancelled = true;
    };
  }, []);

  if (!scope) {
    return (
      <div className="flex min-h-[240px] items-center justify-center text-sm text-muted-foreground">
        Loading menu...
      </div>
    );
  }

  return <MenuManagementPage scope={scope} />;
}
