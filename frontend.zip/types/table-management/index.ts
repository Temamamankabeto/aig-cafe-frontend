export * from "./table.type";
