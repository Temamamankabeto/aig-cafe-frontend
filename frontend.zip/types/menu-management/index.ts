export * from "./menu.type";
